# Argument-driven engineering article

This is an editable IEEEtran journal-style article template with a populated method proposal and a prospective evaluation section.

## Build

Run `latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex` from this directory.

The project uses the IEEEtran class and bibliography style. Both are included when they are unavailable from the local TeX installation. A TeX distribution with TikZ is required.

## Edit before submission

1. Choose the IEEE publication and apply its current author instructions.
2. Replace the affiliation and contact note in `main.tex`.
3. Revise the proposed contributions to match the work actually completed.
4. Replace the prospective evaluation protocol with the approved study design.
5. Enter measured results only after data collection and analysis. Retain uncertainty and protocol deviations.
6. Recheck repository citations if the implementation changes.

The source comments identify the main template controls. The workflow figure remains editable TikZ. The bibliography remains editable BibTeX. The author has supplied no empirical comparison of the proposed process, and every results cell is marked `To be measured`.
